"""SWC review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import io, json, os, sys, types, zipfile, re, shutil, hashlib
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/swin_classification_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
import swin_classification_pipeline.pipeline as P
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
R['P1_static'] = {
    'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'asserts': [(i, l.strip()) for i in code for l in src(i).splitlines() if l.strip().startswith('assert ')],
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Predict', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'carried_module_lines': src(5).count('\n') + 1,
}
# P2 provenance: NOTEBOOK_SOURCE revision vs carried module digest
import subprocess
rev = nb['metadata']['dimer']['generated_from']['revision']; msha = nb['metadata']['dimer']['generated_from']['module_sha256']
at_rev = subprocess.run(['git', '-C', str(repo), 'show', f'{rev}:src/swin_classification_pipeline/pipeline.py'], capture_output=True).stdout
R['P2_provenance'] = {'generated_from_revision': rev, 'recorded_module_sha256': msha,
    'module_sha256_at_that_revision': hashlib.sha256(at_rev).hexdigest(),
    'module_sha256_at_HEAD': hashlib.sha256((repo / 'src/swin_classification_pipeline/pipeline.py').read_bytes()).hexdigest(),
    'notebook_blob_HEAD': subprocess.run(['git', '-C', str(repo), 'rev-parse', 'HEAD:tutorials/swin_classification_colab.ipynb'], capture_output=True, text=True).stdout.strip(),
    'notebook_blob_at_recorded_run_commit_b1382d1': subprocess.run(['git', '-C', str(repo), 'rev-parse', 'b1382d1:tutorials/swin_classification_colab.ipynb'], capture_output=True, text=True).stdout.strip()}

# P3 default synthetic sample: leakage and saturation
ds = out / 'sample'; shutil.rmtree(ds, ignore_errors=True)
P.generate_synthetic_sample(ds, seed=20260910)
man = P.validate_inputs(ds, names=['deterministic synthetic tutorial sample'])
def dig(p): return hashlib.sha256(p.read_bytes()).hexdigest()
files = {str(p.relative_to(ds)): dig(p) for p in sorted(ds.rglob('*.png'))}
val = [k for k in files if k.startswith('val/')]; tr = [k for k in files if k.startswith('train/')]
dup_val = [v for v in val if files[v] in {files[t] for t in tr}]
# trivial colour baseline: nearest class mean colour from train
def meanrgb(k): return np.asarray(Image.open(ds / k).convert('RGB'), dtype=float).reshape(-1, 3).mean(0)
cm = {c: np.mean([meanrgb(k) for k in tr if k.split('/')[1] == c], 0) for c in ('cool', 'warm')}
pred = {v: min(cm, key=lambda c: np.linalg.norm(meanrgb(v) - cm[c])) for v in val}
acc = sum(pred[v] == v.split('/')[1] for v in val) / len(val)
newimg = P.synthetic_new_image(out / 'new.png'); newpred = min(cm, key=lambda c: np.linalg.norm(np.asarray(Image.open(newimg), float).reshape(-1, 3).mean(0) - cm[c]))
R['P3_sample'] = {'split_counts': man['inputs'][0]['split_counts'], 'validator_findings': [(f['code'], f['observed'].get('duplicateGroups') if isinstance(f['observed'], dict) else None) for f in man['findings']],
    'val_images_byte_identical_to_a_train_image': len(dup_val), 'of_val': len(val), 'dup_val_ids': dup_val,
    'distinct_train_images': len({files[t] for t in tr}), 'of_train': len(tr),
    'majority_baseline': P.majority_class_baseline([v.split('/')[1] for v in val])['accuracy'],
    'mean_colour_nearest_centroid_val_accuracy': acc, 'mean_colour_prediction_for_new_image': newpred}

# P4 BYOD zips through the notebook's own sequence (safe_extract_zip -> locate_dataset_root -> copytree -> validate_inputs)
def png(c=(10, 20, 30), s=32):
    b = io.BytesIO(); Image.new('RGB', (s, s), c).save(b, 'PNG'); return b.getvalue()
def good(prefix=''):
    f = {}
    for sp, n in (('train', 4), ('val', 2)):
        for ci, c in enumerate(('a', 'b')):
            for i in range(n):
                f[f'{prefix}{sp}/{c}/{i}.png'] = png((ci * 120 + i, 40 + i * 3 + (sp == 'val') * 50, 9))
    return f
def mkzip(path, files, symlink=None):
    with zipfile.ZipFile(path, 'w') as z:
        for n, d in files.items(): z.writestr(n, d)
        if symlink:
            zi = zipfile.ZipInfo(symlink[0]); zi.external_attr = (0o120777 << 16); z.writestr(zi, symlink[1])
    return path
def run_byod(zp, cap=2048 * 1024 * 1024):
    work = out / 'byodwork'; shutil.rmtree(work, ignore_errors=True); work.mkdir()
    ex = work / 'byod-extracted'; n = P.safe_extract_zip(zp, ex, cap)
    shutil.copytree(P.locate_dataset_root(ex), work / 'dataset')
    m = P.validate_inputs(work / 'dataset')
    return {'expanded': n, 'split_counts': m['inputs'][0]['split_counts'], 'classes': m['inputs'][0]['classes'], 'warnings': [f['code'] for f in m['findings']]}
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:220]}
zd = out / 'zips'; zd.mkdir(exist_ok=True)
cases = {
    'good, top-level train/ val/': good(),
    'good, one wrapper folder': good('mydata/'),
    'macOS zip: wrapper + __MACOSX/': {**good('mydata/'), '__MACOSX/mydata/._x': b'\0'},
    'macOS zip: top-level train/ + __MACOSX/': {**good(), '__MACOSX/._train': b'\0'},
    '.DS_Store inside a class folder': {**good(), 'train/a/.DS_Store': b'\0\0'},
    'README.txt at root': {**good(), 'README.txt': b'hi'},
    'valid/ instead of val/': {k.replace('val/', 'valid/'): v for k, v in good().items()},
    'only one class': {k: v for k, v in good().items() if '/a/' in k},
    'no val/ (train + test)': {k.replace('val/', 'test/'): v for k, v in good().items()},
    'class b missing from val': {k: v for k, v in good().items() if not k.startswith('val/b')},
    'traversal member ../evil.png': {**good(), '../evil.png': png()},
    'text file named .png': {**good(), 'train/a/bad.png': b'not an image'},
    'Cat and cat classes': {**good(), 'train/Cat/0.png': png(), 'train/cat/0.png': png((1, 2, 3))},
}
P4 = [run(n, lambda f=f, n=n: run_byod(mkzip(zd / (re.sub('[^a-z0-9]+', '_', n.lower())[:40] + '.zip'), f))) for n, f in cases.items()]
P4.append(run('symlink member', lambda: run_byod(mkzip(zd / 'sym.zip', good(), symlink=('train/a/link.png', '/etc/passwd')))))
P4.append(run('expanded size above cap (1 KiB cap)', lambda: run_byod(mkzip(zd / 'cap.zip', good()), cap=1024)))
R['P4_byod'] = P4
# P5 upload branch: requires exactly one file; outside Colab without path
c9 = src(9)
R['P5_upload'] = {'has_BYOD_ZIP_PATH': 'BYOD_ZIP_PATH' in c9, 'checks_exactly_one_upload': "len(uploaded) != 1" in c9, 'image_branch_has_path': 'BYOD_IMAGE_PATH' in src(19),
    'new_image_validation_before_model': 'only extension and existence (_check_images); decode/size errors surface inside classify()'}
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:7000])
